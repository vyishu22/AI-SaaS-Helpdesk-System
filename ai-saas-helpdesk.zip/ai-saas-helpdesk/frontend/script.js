/**
 * script.js - Shared JavaScript for AI SaaS Helpdesk
 * Includes: Chat widget, utility functions, shared helpers
 */

// ─── Utility Functions ────────────────────────────────────────────────────────

/**
 * Escapes HTML to prevent XSS
 */
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Returns colored badge HTML for ticket categories
 */
function categoryBadge(category) {
  const map = {
    'Billing': 'billing',
    'Technical': 'technical',
    'Account': 'account',
    'Shipping': 'shipping',
    'General Inquiry': 'general',
  };
  const cls = map[category] || 'general';
  return `<span class="badge badge-${cls}">${escapeHtml(category || 'General')}</span>`;
}

/**
 * Returns colored badge HTML for ticket status
 */
function statusBadge(status) {
  const cls = status === 'Open' ? 'open' : status === 'Closed' ? 'closed' : 'billing';
  return `<span class="badge badge-${cls}">${escapeHtml(status || 'Open')}</span>`;
}

// ─── Chatbot Widget ───────────────────────────────────────────────────────────

const API_BASE = '/api';

// Store chat history for context-aware responses
let chatHistory = [];
let chatInitialized = false;

const chatToggleBtn = document.getElementById('chat-toggle-btn');
const chatBox = document.getElementById('chat-box');
const chatCloseBtn = document.getElementById('chat-close-btn');
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const chatSendBtn = document.getElementById('chat-send-btn');

/**
 * Toggles the chat widget open/closed
 */
function toggleChat() {
  const isHidden = chatBox.classList.contains('hidden');

  if (isHidden) {
    chatBox.classList.remove('hidden');
    chatToggleBtn.innerHTML = '✕';

    // Show initial greeting if first open
    if (!chatInitialized) {
      chatInitialized = true;
      addChatMessage(
        'agent',
        "👋 Hi there! I'm Aria, your AI support assistant. I'm here to help with billing, account issues, technical problems, and more. How can I help you today?"
      );
    }
    chatInput.focus();
  } else {
    chatBox.classList.add('hidden');
    chatToggleBtn.innerHTML = '💬<span class="notif-dot"></span>';
  }
}

// Event listeners for chat
if (chatToggleBtn) chatToggleBtn.addEventListener('click', toggleChat);
if (chatCloseBtn) chatCloseBtn.addEventListener('click', toggleChat);

if (chatSendBtn) {
  chatSendBtn.addEventListener('click', sendChatMessage);
}

if (chatInput) {
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  });
}

/**
 * Adds a message bubble to the chat UI
 */
function addChatMessage(sender, text) {
  if (!chatMessages) return;

  const msgEl = document.createElement('div');
  msgEl.className = `msg ${sender}`;

  const avatar = sender === 'agent' ? '🤖' : '👤';
  msgEl.innerHTML = `
    <div class="msg-avatar">${avatar}</div>
    <div class="msg-bubble">${escapeHtml(text)}</div>
  `;

  chatMessages.appendChild(msgEl);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

/**
 * Shows/hides the typing indicator
 */
function setTypingIndicator(show) {
  const existing = document.getElementById('typing-indicator');
  if (show && !existing) {
    const indicator = document.createElement('div');
    indicator.id = 'typing-indicator';
    indicator.className = 'msg agent';
    indicator.innerHTML = `
      <div class="msg-avatar">🤖</div>
      <div class="typing-indicator">
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
      </div>`;
    chatMessages.appendChild(indicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  } else if (!show && existing) {
    existing.remove();
  }
}

/**
 * Sends a message to the AI chatbot
 */
async function sendChatMessage() {
  if (!chatInput || !chatMessages) return;

  const message = chatInput.value.trim();
  if (!message) return;

  // Add user message to UI
  addChatMessage('user', message);
  chatInput.value = '';
  chatSendBtn.disabled = true;

  // Add to history
  chatHistory.push({ role: 'user', content: message });

  // Show typing indicator
  setTypingIndicator(true);

  try {
    const res = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        history: chatHistory.slice(-6) // Send last 6 exchanges for context
      })
    });

    const data = await res.json();
    setTypingIndicator(false);

    if (!res.ok) throw new Error(data.error || 'Chat request failed');

    const reply = data.response;
    addChatMessage('agent', reply);

    // Add AI response to history
    chatHistory.push({ role: 'assistant', content: reply });

    // Keep history manageable
    if (chatHistory.length > 20) {
      chatHistory = chatHistory.slice(-20);
    }

  } catch (err) {
    setTypingIndicator(false);
    addChatMessage('agent', "I'm sorry, I'm having trouble connecting right now. Please try again in a moment, or submit a support ticket for assistance.");
  } finally {
    chatSendBtn.disabled = false;
    chatInput.focus();
  }
}
