# 🤖 AI SaaS Helpdesk System

A full-stack customer support automation platform powered by AI. Submit tickets, chat with an AI assistant, and let support agents generate empathetic replies with one click.

## ✨ Features

- **Smart Ticket Submission** — Auto-classifies tickets into Billing, Technical, Account, Shipping, or General Inquiry using AI
- **Empathetic AI Chatbot** — Real-time chat assistant with warm, professional tone
- **Agent Dashboard** — View all tickets with AI-generated reply suggestions
- **FAQ Generator** — Convert support tickets into helpful FAQ entries automatically

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python Flask |
| Database | MongoDB (pymongo) with in-memory fallback |
| AI | OpenRouter API (GPT-3.5-turbo) |
| Frontend | Vanilla HTML/CSS/JavaScript |

## 📁 Project Structure

```
ai-saas-helpdesk/
├── backend/
│   ├── app.py          # Flask entry point
│   ├── routes.py       # API route handlers
│   ├── ai_service.py   # OpenRouter API integration
│   └── db.py           # MongoDB operations
├── frontend/
│   ├── index.html      # Homepage + chatbot
│   ├── submit_ticket.html  # Ticket submission form
│   ├── dashboard.html  # Agent dashboard
│   ├── faq.html        # FAQ knowledge base
│   ├── style.css       # Shared styles
│   └── script.js       # Shared JS + chatbot logic
├── requirements.txt
├── .env.example
└── README.md
```

## 🚀 Quick Start

### 1. Clone & Install

```bash
cd ai-saas-helpdesk
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and add your OPENROUTER_API_KEY
```

### 3. Start MongoDB (optional — has in-memory fallback)

```bash
mongod --dbpath /data/db
```

### 4. Run the Server

```bash
cd backend
python app.py
```

Visit: **http://localhost:5000**

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/tickets` | Submit new ticket |
| GET | `/api/tickets` | Fetch all tickets |
| POST | `/api/chat` | AI chatbot message |
| POST | `/api/suggest-reply/<ticket_id>` | Generate AI reply for agent |
| POST | `/api/generate-faq/<ticket_id>` | Convert ticket to FAQ |
| GET | `/api/faqs` | Fetch all FAQs |
| GET | `/api/health` | Health check |

## 💡 Getting an OpenRouter API Key

1. Visit [openrouter.ai](https://openrouter.ai)
2. Sign up for a free account
3. Go to API Keys and generate a key
4. Add it to your `.env` file

## 📝 Notes

- If MongoDB is not available, the system automatically falls back to in-memory storage
- All AI responses are designed to be empathetic, professional, and supportive
- The chatbot maintains conversation context for more relevant responses
