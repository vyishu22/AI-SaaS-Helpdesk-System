"""
db.py - MongoDB database connection and helper functions
"""

import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
from datetime import datetime

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = os.getenv("DB_NAME", "helpdesk_db")

# Initialize MongoDB client
try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    client.admin.command("ping")  # Test connection
    db = client[DB_NAME]
    tickets_collection = db["tickets"]
    faqs_collection = db["faqs"]
    print(f"✅ Connected to MongoDB: {DB_NAME}")
except (ConnectionFailure, ServerSelectionTimeoutError) as e:
    print(f"⚠️  MongoDB connection failed: {e}")
    print("Running with in-memory storage fallback...")
    db = None
    tickets_collection = None
    faqs_collection = None


# ─── In-memory fallback storage ───────────────────────────────────────────────
_memory_tickets = {}
_memory_faqs = {}
_ticket_counter = 1


def _next_ticket_id():
    global _ticket_counter
    tid = f"TKT-{_ticket_counter:04d}"
    _ticket_counter += 1
    return tid


# ─── Ticket operations ────────────────────────────────────────────────────────

def save_ticket(ticket_data: dict) -> str:
    """Save a ticket to DB (or memory). Returns the ticket_id."""
    ticket_data["ticket_id"] = _next_ticket_id()
    ticket_data["created_at"] = datetime.utcnow().isoformat()
    ticket_data["status"] = "Open"
    ticket_data["priority"] = ticket_data.get("priority", "Medium")
    ticket_data["category"] = ticket_data.get("category", "General Inquiry")
    ticket_data["sentiment"] = ticket_data.get("sentiment", "Neutral")
    ticket_data["ai_summary"] = ticket_data.get("ai_summary", "")

    if tickets_collection is not None:
        tickets_collection.insert_one(ticket_data)
        ticket_data.pop("_id", None)
    else:
        _memory_tickets[ticket_data["ticket_id"]] = ticket_data

    return ticket_data["ticket_id"]


def get_all_tickets() -> list:
    """Retrieve all tickets."""
    if tickets_collection is not None:
        tickets = list(tickets_collection.find({}, {"_id": 0}))
    else:
        tickets = list(_memory_tickets.values())

    # Sort by created_at descending
    tickets.sort(key=lambda t: t.get("created_at", ""), reverse=True)
    return tickets


def get_ticket_by_id(ticket_id: str) -> dict:
    """Get a single ticket by ID."""
    if tickets_collection is not None:
        ticket = tickets_collection.find_one({"ticket_id": ticket_id}, {"_id": 0})
        return ticket
    else:
        return _memory_tickets.get(ticket_id)


def update_ticket_category(ticket_id: str, category: str):
    """Update the category of a ticket."""
    if tickets_collection is not None:
        tickets_collection.update_one(
            {"ticket_id": ticket_id},
            {"$set": {"category": category}}
        )
    else:
        if ticket_id in _memory_tickets:
            _memory_tickets[ticket_id]["category"] = category


def update_ticket_status(ticket_id: str, status: str):
    """Update ticket status."""
    if tickets_collection is not None:
        tickets_collection.update_one(
            {"ticket_id": ticket_id},
            {"$set": {"status": status}}
        )
    else:
        if ticket_id in _memory_tickets:
            _memory_tickets[ticket_id]["status"] = status


def update_ticket_fields(ticket_id: str, fields: dict):
    """Update arbitrary fields on a ticket (status, priority, notes, etc.)."""
    if tickets_collection is not None:
        tickets_collection.update_one(
            {"ticket_id": ticket_id},
            {"$set": fields}
        )
    else:
        if ticket_id in _memory_tickets:
            _memory_tickets[ticket_id].update(fields)


# ─── FAQ operations ───────────────────────────────────────────────────────────

def save_faq(ticket_id: str, question: str, answer: str) -> dict:
    """Save a generated FAQ entry."""
    faq = {
        "ticket_id": ticket_id,
        "question": question,
        "answer": answer,
        "created_at": datetime.utcnow().isoformat()
    }

    if faqs_collection is not None:
        # Upsert: replace if already exists for this ticket
        faqs_collection.replace_one(
            {"ticket_id": ticket_id},
            faq,
            upsert=True
        )
    else:
        _memory_faqs[ticket_id] = faq

    return faq


def get_all_faqs() -> list:
    """Retrieve all FAQs."""
    if faqs_collection is not None:
        return list(faqs_collection.find({}, {"_id": 0}))
    else:
        return list(_memory_faqs.values())


def get_faq_by_ticket(ticket_id: str) -> dict:
    """Get FAQ for a specific ticket."""
    if faqs_collection is not None:
        return faqs_collection.find_one({"ticket_id": ticket_id}, {"_id": 0})
    else:
        return _memory_faqs.get(ticket_id)
