"""
routes.py - Flask API route definitions
Handles ticket submission, chat, and AI-powered features
"""

from flask import Blueprint, request, jsonify
from db import (
    save_ticket, get_all_tickets, get_ticket_by_id,
    update_ticket_category, update_ticket_fields, save_faq, get_all_faqs
)
from ai_service import (
    classify_ticket, chat_with_support,
    generate_reply_suggestion, generate_faq,
    analyze_sentiment, generate_ticket_summary, detect_priority
)

api = Blueprint("api", __name__)


# ─── Ticket Routes ────────────────────────────────────────────────────────────

@api.route("/tickets", methods=["POST"])
def submit_ticket():
    """
    POST /api/tickets
    Submit a new support ticket. AI classifies category, sentiment, priority, and summary.
    """
    data = request.get_json()

    # Validate required fields
    required = ["name", "email", "subject", "message"]
    missing = [f for f in required if not data.get(f, "").strip()]
    if missing:
        return jsonify({"error": f"Missing required fields: {', '.join(missing)}"}), 400

    # Basic email format check
    email = data["email"].strip()
    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"error": "Please provide a valid email address."}), 400

    # Prepare ticket data
    ticket = {
        "name": data["name"].strip(),
        "email": email,
        "subject": data["subject"].strip(),
        "message": data["message"].strip(),
        "priority": data.get("priority", "").strip() or None,  # may be set by AI
    }

    # ── AI enrichment (all in parallel conceptually, sequential here) ──
    try:
        ticket["category"] = classify_ticket(ticket["message"], ticket["subject"])
    except Exception:
        ticket["category"] = "General Inquiry"

    try:
        ticket["sentiment"] = analyze_sentiment(ticket["message"])
    except Exception:
        ticket["sentiment"] = "Neutral"

    try:
        # Only auto-detect priority if not manually set
        if not ticket["priority"]:
            ticket["priority"] = detect_priority(ticket["message"], ticket["category"])
    except Exception:
        ticket["priority"] = ticket.get("priority") or "Medium"

    try:
        ticket["ai_summary"] = generate_ticket_summary(ticket)
    except Exception:
        ticket["ai_summary"] = ""

    # Save to database
    ticket_id = save_ticket(ticket)

    return jsonify({
        "success": True,
        "ticket_id": ticket_id,
        "category": ticket["category"],
        "sentiment": ticket["sentiment"],
        "priority": ticket["priority"],
        "message": "Your ticket has been submitted successfully. Our team will get back to you shortly."
    }), 201


@api.route("/tickets", methods=["GET"])
def fetch_tickets():
    """
    GET /api/tickets?search=&status=&category=&priority=
    Retrieve tickets with optional filtering.
    """
    tickets = get_all_tickets()

    # Optional query filters
    search = request.args.get("search", "").lower().strip()
    status_filter = request.args.get("status", "").strip()
    category_filter = request.args.get("category", "").strip()
    priority_filter = request.args.get("priority", "").strip()

    if search:
        tickets = [
            t for t in tickets
            if search in t.get("name", "").lower()
            or search in t.get("subject", "").lower()
            or search in t.get("message", "").lower()
            or search in t.get("ticket_id", "").lower()
            or search in t.get("email", "").lower()
        ]

    if status_filter:
        tickets = [t for t in tickets if t.get("status") == status_filter]

    if category_filter:
        tickets = [t for t in tickets if t.get("category") == category_filter]

    if priority_filter:
        tickets = [t for t in tickets if t.get("priority") == priority_filter]

    return jsonify({"tickets": tickets, "count": len(tickets)}), 200


@api.route("/tickets/<ticket_id>", methods=["PATCH"])
def update_ticket(ticket_id):
    """
    PATCH /api/tickets/<ticket_id>
    Update ticket fields: status, priority, notes.
    """
    ticket = get_ticket_by_id(ticket_id)
    if not ticket:
        return jsonify({"error": f"Ticket {ticket_id} not found"}), 404

    data = request.get_json()
    allowed = ["status", "priority", "notes"]
    updates = {k: v for k, v in data.items() if k in allowed and v is not None}

    if not updates:
        return jsonify({"error": "No valid fields to update"}), 400

    update_ticket_fields(ticket_id, updates)
    return jsonify({"success": True, "ticket_id": ticket_id, "updated": updates}), 200


# ─── Chat Route ───────────────────────────────────────────────────────────────

@api.route("/chat", methods=["POST"])
def chat():
    """
    POST /api/chat
    Handle chatbot messages with empathetic AI responses.
    """
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    chat_history = data.get("history", [])
    response = chat_with_support(user_message, chat_history)

    return jsonify({"success": True, "response": response}), 200


# ─── AI Reply Suggestion ──────────────────────────────────────────────────────

@api.route("/suggest-reply/<ticket_id>", methods=["POST"])
def suggest_reply(ticket_id):
    """
    POST /api/suggest-reply/<ticket_id>
    Generate an AI-suggested reply for a support agent.
    """
    ticket = get_ticket_by_id(ticket_id)
    if not ticket:
        return jsonify({"error": f"Ticket {ticket_id} not found"}), 404

    suggested_reply = generate_reply_suggestion(ticket)
    return jsonify({
        "success": True,
        "ticket_id": ticket_id,
        "suggested_reply": suggested_reply
    }), 200


# ─── FAQ Generator ────────────────────────────────────────────────────────────

@api.route("/generate-faq/<ticket_id>", methods=["POST"])
def generate_faq_endpoint(ticket_id):
    """
    POST /api/generate-faq/<ticket_id>
    Convert a support ticket into a FAQ entry and store it.
    """
    ticket = get_ticket_by_id(ticket_id)
    if not ticket:
        return jsonify({"error": f"Ticket {ticket_id} not found"}), 404

    faq_data = generate_faq(ticket)
    saved_faq = save_faq(
        ticket_id=ticket_id,
        question=faq_data["question"],
        answer=faq_data["answer"]
    )
    return jsonify({"success": True, "faq": saved_faq}), 200


@api.route("/faqs", methods=["GET"])
def fetch_faqs():
    """GET /api/faqs — Retrieve all generated FAQs."""
    faqs = get_all_faqs()
    return jsonify({"faqs": faqs, "count": len(faqs)}), 200


# ─── Analytics ────────────────────────────────────────────────────────────────

@api.route("/analytics", methods=["GET"])
def analytics():
    """
    GET /api/analytics
    Returns aggregated stats for the dashboard overview panel.
    """
    tickets = get_all_tickets()
    total = len(tickets)

    by_status = {}
    by_category = {}
    by_priority = {}
    by_sentiment = {}

    for t in tickets:
        s = t.get("status", "Open")
        by_status[s] = by_status.get(s, 0) + 1

        c = t.get("category", "General Inquiry")
        by_category[c] = by_category.get(c, 0) + 1

        p = t.get("priority", "Medium")
        by_priority[p] = by_priority.get(p, 0) + 1

        sent = t.get("sentiment", "Neutral")
        by_sentiment[sent] = by_sentiment.get(sent, 0) + 1

    return jsonify({
        "total": total,
        "by_status": by_status,
        "by_category": by_category,
        "by_priority": by_priority,
        "by_sentiment": by_sentiment,
    }), 200


# ─── Health Check ─────────────────────────────────────────────────────────────

@api.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "AI SaaS Helpdesk"}), 200

