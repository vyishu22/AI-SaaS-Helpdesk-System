"""
app.py - Main Flask application entry point for AI SaaS Helpdesk System
"""

import os
from flask import Flask, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ─── App Setup ────────────────────────────────────────────────────────────────

app = Flask(__name__, static_folder="../frontend", static_url_path="")
CORS(app)  # Allow cross-origin requests from frontend

# ─── Register API Blueprint ───────────────────────────────────────────────────

from routes import api
app.register_blueprint(api, url_prefix="/api")

# ─── Serve Frontend Pages ─────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/<path:filename>")
def serve_static(filename):
    return send_from_directory(app.static_folder, filename)


# ─── Run Server ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "true").lower() == "true"
    print(f"\n🚀 AI SaaS Helpdesk running at http://localhost:{port}")
    print(f"   Dashboard: http://localhost:{port}/dashboard.html")
    print(f"   Submit Ticket: http://localhost:{port}/submit_ticket.html\n")
    app.run(host="0.0.0.0", port=port, debug=debug)
