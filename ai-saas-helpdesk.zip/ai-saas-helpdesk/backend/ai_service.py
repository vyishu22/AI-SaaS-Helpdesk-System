"""
ai_service.py - Handles all OpenRouter API interactions
Provides empathetic AI responses for customer support
"""

import os
import requests
import json

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL = "openai/gpt-3.5-turbo"

SUPPORT_SYSTEM_PROMPT = """You are an empathetic, professional customer support assistant for a SaaS company.
Your tone must always be:
- Warm, caring, and understanding
- Professional and polished
- Solution-oriented and helpful
- Never dismissive or robotic

Always acknowledge the customer's frustration before providing help. 
Start responses with empathy, e.g., "I'm really sorry you're experiencing this issue. I understand how frustrating that can be."
Keep responses concise (3-5 sentences for chat, longer for ticket replies)."""


def _get_headers():
    """Build headers with the current API key (read fresh each call for hot-reload support)."""
    api_key = os.getenv("OPENROUTER_API_KEY", "")
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:5000",
        "X-Title": "AI SaaS Helpdesk"
    }


def call_openrouter(messages: list, max_tokens: int = 500) -> str:
    """
    Generic function to call OpenRouter API.
    Returns the AI response text or an error message.
    """
    api_key = os.getenv("OPENROUTER_API_KEY", "")
    if not api_key:
        return "AI service is not configured. Please set the OPENROUTER_API_KEY environment variable."

    payload = {
        "model": MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.7
    }

    try:
        response = requests.post(
            OPENROUTER_URL,
            headers=_get_headers(),
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"].strip()
    except requests.exceptions.Timeout:
        return "I apologize for the delay. Our AI service is temporarily unavailable. Please try again shortly."
    except requests.exceptions.HTTPError as e:
        return f"I'm sorry, there was an issue connecting to our AI service (HTTP {e.response.status_code}). Please try again."
    except (KeyError, IndexError):
        return "I'm sorry, I received an unexpected response. Please try again."
    except Exception:
        return "I'm sorry, an unexpected error occurred. Please try again later."


def classify_ticket(message: str, subject: str) -> str:
    """
    Classifies a support ticket into one of the predefined categories.
    Returns the category as a string.
    """
    categories = ["Billing", "Account", "Technical", "Shipping", "General Inquiry"]

    messages = [
        {
            "role": "system",
            "content": (
                "You are a ticket classification assistant. "
                "Classify the support ticket into EXACTLY one of these categories: "
                f"{', '.join(categories)}. "
                "Respond with ONLY the category name, nothing else."
            )
        },
        {
            "role": "user",
            "content": f"Subject: {subject}\nMessage: {message}"
        }
    ]

    result = call_openrouter(messages, max_tokens=20)

    # Validate the response is one of the expected categories
    for category in categories:
        if category.lower() in result.lower():
            return category

    return "General Inquiry"  # Default fallback


def chat_with_support(user_message: str, chat_history: list = None) -> str:
    """
    Handles chat interactions with an empathetic support AI.
    Maintains context through chat_history.
    """
    messages = [{"role": "system", "content": SUPPORT_SYSTEM_PROMPT}]

    # Add previous chat history for context
    if chat_history:
        for entry in chat_history[-6:]:  # Keep last 6 messages for context
            messages.append(entry)

    messages.append({"role": "user", "content": user_message})

    return call_openrouter(messages, max_tokens=300)


def generate_reply_suggestion(ticket: dict) -> str:
    """
    Generates an empathetic, professional reply suggestion for a support agent.
    """
    messages = [
        {
            "role": "system",
            "content": (
                SUPPORT_SYSTEM_PROMPT +
                "\nYou are generating a reply for a support agent to send to a customer. "
                "Write a complete, ready-to-send email response. "
                "Include a greeting, empathetic acknowledgment, helpful resolution steps, and a professional closing."
            )
        },
        {
            "role": "user",
            "content": (
                f"Generate a professional reply for this support ticket:\n\n"
                f"Customer Name: {ticket.get('name', 'Customer')}\n"
                f"Subject: {ticket.get('subject', 'Support Request')}\n"
                f"Category: {ticket.get('category', 'General Inquiry')}\n"
                f"Message: {ticket.get('message', '')}\n\n"
                "Write a complete email reply."
            )
        }
    ]

    return call_openrouter(messages, max_tokens=500)


def generate_faq(ticket: dict) -> dict:
    """
    Converts a support ticket into a FAQ entry.
    Returns a dict with 'question' and 'answer' keys.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are a FAQ generator for a SaaS company help center. "
                "Convert customer support issues into clear, helpful FAQ entries. "
                "Respond in valid JSON format with exactly two keys: 'question' and 'answer'. "
                "The question should be generalized (not specific to one person). "
                "The answer should be helpful and actionable."
            )
        },
        {
            "role": "user",
            "content": (
                f"Convert this support ticket into a FAQ entry:\n\n"
                f"Subject: {ticket.get('subject', '')}\n"
                f"Category: {ticket.get('category', '')}\n"
                f"Message: {ticket.get('message', '')}\n\n"
                'Respond ONLY with JSON like: {"question": "...", "answer": "..."}'
            )
        }
    ]

    result = call_openrouter(messages, max_tokens=300)

    # Parse JSON response
    try:
        # Strip markdown code blocks if present
        cleaned = result.strip().strip("```json").strip("```").strip()
        faq_data = json.loads(cleaned)
        return {
            "question": faq_data.get("question", "How can I resolve this issue?"),
            "answer": faq_data.get("answer", result)
        }
    except json.JSONDecodeError:
        # Fallback if JSON parsing fails
        return {
            "question": f"How can I resolve issues with: {ticket.get('subject', 'my request')}?",
            "answer": result
        }


def analyze_sentiment(message: str) -> str:
    """
    Analyzes the emotional tone of a customer message.
    Returns: 'Frustrated', 'Neutral', or 'Satisfied'
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are a sentiment analysis tool. "
                "Classify the customer message sentiment as EXACTLY one of: Frustrated, Neutral, Satisfied. "
                "Respond with ONLY the single word, nothing else."
            )
        },
        {"role": "user", "content": message}
    ]
    result = call_openrouter(messages, max_tokens=10).strip()
    for label in ["Frustrated", "Neutral", "Satisfied"]:
        if label.lower() in result.lower():
            return label
    return "Neutral"


def generate_ticket_summary(ticket: dict) -> str:
    """
    Generates a concise one-sentence summary of a support ticket for quick agent scanning.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are a support ticket summarizer. "
                "Summarize the customer's issue in ONE clear sentence (max 20 words). "
                "Focus on the core problem, not pleasantries."
            )
        },
        {
            "role": "user",
            "content": f"Subject: {ticket.get('subject', '')}\nMessage: {ticket.get('message', '')}"
        }
    ]
    return call_openrouter(messages, max_tokens=60)


def detect_priority(message: str, category: str) -> str:
    """
    Suggests ticket priority based on message urgency and category.
    Returns: 'High', 'Medium', or 'Low'
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are a support ticket priority classifier. "
                "Based on the message urgency, emotional intensity, and category, "
                "classify the priority as EXACTLY one of: High, Medium, Low. "
                "High = urgent/angry/service-down. Low = general questions/minor issues. "
                "Respond with ONLY the priority word."
            )
        },
        {
            "role": "user",
            "content": f"Category: {category}\nMessage: {message}"
        }
    ]
    result = call_openrouter(messages, max_tokens=10).strip()
    for level in ["High", "Medium", "Low"]:
        if level.lower() in result.lower():
            return level
    return "Medium"
